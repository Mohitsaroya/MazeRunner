var searchData=
[
  ['lost_5fplayer_0',['lost_player',['../npc_8c.html#a8d4d422876611bac3f9aa5032aa3be6e',1,'lost_player:&#160;npc.c'],['../npc_8h.html#a8d4d422876611bac3f9aa5032aa3be6e',1,'lost_player:&#160;npc.c']]],
  ['lost_5fstate_1',['lost_state',['../npc_8c.html#ad31b58937102672c22e7aa4df9c38a95',1,'lost_state:&#160;npc.c'],['../npc_8h.html#ad31b58937102672c22e7aa4df9c38a95',1,'lost_state:&#160;npc.c']]]
];
