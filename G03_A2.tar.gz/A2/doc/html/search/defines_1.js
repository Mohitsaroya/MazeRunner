var searchData=
[
  ['dave_5fheight_0',['DAVE_HEIGHT',['../npc_8h.html#afe105ee96c69cda26c0b892b4bdab338',1,'npc.h']]],
  ['dave_5fwidth_1',['DAVE_WIDTH',['../npc_8h.html#a44273a2234eefdf70f5d0724e9755bce',1,'npc.h']]]
];
