var searchData=
[
  ['handle_5fpause_5fmenu_0',['handle_pause_menu',['../interface_8c.html#a00b7f592d04d6b504528bed93b878c6b',1,'handle_pause_menu(WINDOW *gamewin):&#160;interface.c'],['../interface_8h.html#a00b7f592d04d6b504528bed93b878c6b',1,'handle_pause_menu(WINDOW *gamewin):&#160;interface.c']]],
  ['handle_5fretry_1',['handle_retry',['../interface_8c.html#aaada437d87d84621bc1f3f3cb81f0640',1,'handle_retry(WINDOW *gamewin):&#160;interface.c'],['../interface_8h.html#aaada437d87d84621bc1f3f3cb81f0640',1,'handle_retry(WINDOW *gamewin):&#160;interface.c']]]
];
