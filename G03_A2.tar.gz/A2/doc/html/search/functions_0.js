var searchData=
[
  ['create_5fexit_5fpoint_0',['create_exit_point',['../maze_8c.html#aa9ca01bd7f7947fa4d7d948c75364d99',1,'create_exit_point(int start_y, int start_x, int maze_h, int maze_w):&#160;maze.c'],['../maze_8h.html#aa9ca01bd7f7947fa4d7d948c75364d99',1,'create_exit_point(int start_y, int start_x, int maze_h, int maze_w):&#160;maze.c']]]
];
