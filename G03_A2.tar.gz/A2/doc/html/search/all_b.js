var searchData=
[
  ['next_0',['NEXT',['../interface_8h.html#a2be29dbf95b4a2c822f307a5b8141184',1,'interface.h']]],
  ['notes_1',['Notes',['../index.html#autotoc_md11',1,'']]],
  ['npc_2ec_2',['npc.c',['../npc_8c.html',1,'']]],
  ['npc_2eh_3',['npc.h',['../npc_8h.html',1,'']]],
  ['npc_5finit_4',['npc_init',['../npc_8c.html#af011a511c7381bc975cdf0f9abfaa70e',1,'npc_init(int parent_height, int parent_width):&#160;npc.c'],['../npc_8h.html#af011a511c7381bc975cdf0f9abfaa70e',1,'npc_init(int parent_height, int parent_width):&#160;npc.c']]]
];
