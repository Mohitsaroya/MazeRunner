var searchData=
[
  ['quit_0',['QUIT',['../interface_8h.html#ad24e2b54375e12474e65ebf7175988fb',1,'interface.h']]],
  ['quitcard_1',['quitcard',['../gameCards_8c.html#ab0193b8e347c46c9b61f5ce6abc66681',1,'quitCard(WINDOW *win):&#160;gameCards.c'],['../gameCards_8h.html#ab0193b8e347c46c9b61f5ce6abc66681',1,'quitCard(WINDOW *win):&#160;gameCards.c']]],
  ['quitscreen_2',['quitscreen',['../interface_8c.html#a6820372449921205c1c471756e616b56',1,'quitScreen(WINDOW *parent):&#160;interface.c'],['../interface_8h.html#a6820372449921205c1c471756e616b56',1,'quitScreen(WINDOW *parent):&#160;interface.c']]]
];
