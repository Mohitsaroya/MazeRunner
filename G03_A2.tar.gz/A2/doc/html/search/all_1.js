var searchData=
[
  ['border_0',['BORDER',['../interface_8h.html#a6d0652ae6ea6a5c4fef68baf139fd085',1,'interface.h']]],
  ['building_1',['Building',['../index.html#autotoc_md6',1,'']]],
  ['building_20and_20testing_2',['Building and Testing',['../index.html#autotoc_md10',1,'']]]
];
