var searchData=
[
  ['dave_5fface_0',['dave_face',['../npc_8c.html#ade77fe84138f92b98aee09db4efab88d',1,'dave_face:&#160;npc.c'],['../npc_8h.html#ade77fe84138f92b98aee09db4efab88d',1,'dave_face:&#160;npc.c']]]
];
