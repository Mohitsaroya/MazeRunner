var searchData=
[
  ['next_0',['NEXT',['../interface_8h.html#a2be29dbf95b4a2c822f307a5b8141184',1,'interface.h']]]
];
