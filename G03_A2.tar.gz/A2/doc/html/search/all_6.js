var searchData=
[
  ['game_0',['Running the Game',['../index.html#autotoc_md5',1,'']]],
  ['game_20controls_1',['Game Controls',['../index.html#autotoc_md8',1,'']]],
  ['gamecards_2ec_2',['gameCards.c',['../gameCards_8c.html',1,'']]],
  ['gamecards_2eh_3',['gameCards.h',['../gameCards_8h.html',1,'']]],
  ['goodbye_4',['goodbye',['../interface_8c.html#a6c26e55708f4a50b98128ebb0cf4d161',1,'goodBye(WINDOW *parent):&#160;interface.c'],['../interface_8h.html#a6c26e55708f4a50b98128ebb0cf4d161',1,'goodBye(WINDOW *parent):&#160;interface.c']]]
];
