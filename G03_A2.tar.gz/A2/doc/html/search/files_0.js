var searchData=
[
  ['gamecards_2ec_0',['gameCards.c',['../gameCards_8c.html',1,'']]],
  ['gamecards_2eh_1',['gameCards.h',['../gameCards_8h.html',1,'']]]
];
