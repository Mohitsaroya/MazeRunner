var searchData=
[
  ['border_0',['BORDER',['../interface_8h.html#a6d0652ae6ea6a5c4fef68baf139fd085',1,'interface.h']]]
];
