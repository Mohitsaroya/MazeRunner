var searchData=
[
  ['npc_5finit_0',['npc_init',['../npc_8c.html#af011a511c7381bc975cdf0f9abfaa70e',1,'npc_init(int parent_height, int parent_width):&#160;npc.c'],['../npc_8h.html#af011a511c7381bc975cdf0f9abfaa70e',1,'npc_init(int parent_height, int parent_width):&#160;npc.c']]]
];
