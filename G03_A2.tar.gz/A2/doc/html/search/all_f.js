var searchData=
[
  ['reached_5fexit_0',['reached_exit',['../maze_8c.html#a33b4fa86e798bc4b081f16b99b613508',1,'reached_exit(int player_y, int player_x, ExitPoint exit):&#160;maze.c'],['../maze_8h.html#a33b4fa86e798bc4b081f16b99b613508',1,'reached_exit(int player_y, int player_x, ExitPoint exit):&#160;maze.c']]],
  ['readme_2emd_1',['README.md',['../README_8md.html',1,'']]],
  ['requirements_2',['Requirements',['../index.html#autotoc_md3',1,'']]],
  ['retry_3',['RETRY',['../interface_8h.html#ab56f9f937902b77e7d2b1e52e004ce84',1,'interface.h']]],
  ['retrycard_4',['retrycard',['../gameCards_8c.html#ae33d8e9b2f4ba72b2d2fe71965324750',1,'retryCard(WINDOW *win):&#160;gameCards.c'],['../gameCards_8h.html#ae33d8e9b2f4ba72b2d2fe71965324750',1,'retryCard(WINDOW *win):&#160;gameCards.c']]],
  ['running_20the_20game_5',['Running the Game',['../index.html#autotoc_md5',1,'']]]
];
