var searchData=
[
  ['code_20documentation_0',['Code Documentation',['../index.html#autotoc_md9',1,'']]],
  ['controls_1',['Game Controls',['../index.html#autotoc_md8',1,'']]],
  ['create_5fexit_5fpoint_2',['create_exit_point',['../maze_8c.html#aa9ca01bd7f7947fa4d7d948c75364d99',1,'create_exit_point(int start_y, int start_x, int maze_h, int maze_w):&#160;maze.c'],['../maze_8h.html#aa9ca01bd7f7947fa4d7d948c75364d99',1,'create_exit_point(int start_y, int start_x, int maze_h, int maze_w):&#160;maze.c']]]
];
