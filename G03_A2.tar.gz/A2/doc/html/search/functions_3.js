var searchData=
[
  ['goodbye_0',['goodbye',['../interface_8c.html#a6c26e55708f4a50b98128ebb0cf4d161',1,'goodBye(WINDOW *parent):&#160;interface.c'],['../interface_8h.html#a6c26e55708f4a50b98128ebb0cf4d161',1,'goodBye(WINDOW *parent):&#160;interface.c']]]
];
