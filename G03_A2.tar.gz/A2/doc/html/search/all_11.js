var searchData=
[
  ['testing_0',['Building and Testing',['../index.html#autotoc_md10',1,'']]],
  ['the_20game_1',['Running the Game',['../index.html#autotoc_md5',1,'']]],
  ['title_5fscreen_2',['title_screen',['../interface_8c.html#a650bea29ebe34fb440967eb0617df827',1,'title_screen():&#160;interface.c'],['../interface_8h.html#a8211e154784bf651bf1a385e1babbecd',1,'title_screen(void):&#160;interface.c']]],
  ['titlecard_3',['titlecard',['../gameCards_8c.html#a946643060c7bb1e7df1d878898d6a320',1,'titleCard(WINDOW *win):&#160;gameCards.c'],['../gameCards_8h.html#a946643060c7bb1e7df1d878898d6a320',1,'titleCard(WINDOW *win):&#160;gameCards.c']]]
];
